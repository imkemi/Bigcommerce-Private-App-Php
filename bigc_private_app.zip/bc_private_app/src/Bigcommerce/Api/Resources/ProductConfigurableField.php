<?php

namespace Bigcommerce\Api\Resources;

use Bigcommerce\Api\Resource;
use Bigcommerce\Api\Client;

/**
 * A configurable field on a product.
 */
class ProductConfigurableField extends Resource
{

}

